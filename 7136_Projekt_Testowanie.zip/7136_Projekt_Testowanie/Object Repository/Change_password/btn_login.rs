<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>przycisk &quot;dalej&quot;</description>
   <name>btn_login</name>
   <tag></tag>
   <elementGuidId>90d09296-2b9e-460d-a038-5fbc8a90150d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#login-user-click-button </value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

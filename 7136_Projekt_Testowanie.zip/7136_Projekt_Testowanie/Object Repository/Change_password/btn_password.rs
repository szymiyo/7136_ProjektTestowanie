<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>przycisk zatwierdzający hasło</description>
   <name>btn_password</name>
   <tag></tag>
   <elementGuidId>138698df-350f-460d-a0bc-0a1740c30094</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#login-pass-click-button</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

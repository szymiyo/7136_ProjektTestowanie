<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Input &quot;Nowe hasło&quot;</description>
   <name>inp_pass_new</name>
   <tag></tag>
   <elementGuidId>f3d89106-9a3a-46d2-97e0-b70e25339c1c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>[formcontrolname='newPassword']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Przycisk &quot;Hasło i logowanie&quot;</description>
   <name>btn_settings_pass</name>
   <tag></tag>
   <elementGuidId>ad66d701-a862-4265-b38d-c6f3d38e1875</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a[href='/web-ca24-demo/settings/login'] span</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

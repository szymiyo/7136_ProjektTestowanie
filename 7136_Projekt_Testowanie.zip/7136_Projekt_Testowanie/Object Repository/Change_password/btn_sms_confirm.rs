<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Przycisk &quot;Zatwierdź&quot;</description>
   <name>btn_sms_confirm</name>
   <tag></tag>
   <elementGuidId>7ec401c7-e2a8-48b1-a786-1a303b49f37c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>.ml-auto</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>input &quot;Potwierdź hasło&quot;</description>
   <name>inp_pass_confirm</name>
   <tag></tag>
   <elementGuidId>80a1f0f4-bc21-4a55-9269-c53c8e6854a0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>[formcontrolname='confirmPassword']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

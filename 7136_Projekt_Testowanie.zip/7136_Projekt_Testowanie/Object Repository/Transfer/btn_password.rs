<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>przycisk zatwierdzający hasło</description>
   <name>btn_password</name>
   <tag></tag>
   <elementGuidId>a650da03-e136-4b6b-b94c-6e97099895ce</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#login-pass-click-button</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[@id='login-pass-click-button']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

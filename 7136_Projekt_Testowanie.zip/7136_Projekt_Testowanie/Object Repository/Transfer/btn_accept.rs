<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>przycisk &quot;zatwierdź&quot;</description>
   <name>btn_accept</name>
   <tag></tag>
   <elementGuidId>40092036-7d32-42c3-a157-5e3ac3c5a468</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>.mr-0</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

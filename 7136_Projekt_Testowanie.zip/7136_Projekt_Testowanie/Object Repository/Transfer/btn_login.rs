<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>przycisk &quot;dalej&quot;</description>
   <name>btn_login</name>
   <tag></tag>
   <elementGuidId>aa72d09e-9a92-49cb-8796-c1aa0804c37a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#login-user-click-button </value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

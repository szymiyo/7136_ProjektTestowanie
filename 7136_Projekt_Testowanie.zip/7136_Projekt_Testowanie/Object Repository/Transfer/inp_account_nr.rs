<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>input &quot;rachunek odbiorcy&quot;</description>
   <name>inp_account_nr</name>
   <tag></tag>
   <elementGuidId>29255697-d19c-4ca9-8171-b41dc748e1bb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//input[@id='recipient-iban']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

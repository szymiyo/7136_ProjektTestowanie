import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable

//Włączenie przeglądaki
WebUI.openBrowser(rawUrl=GlobalVariable.url)
WebUI.maximizeWindow()

//Zalogowanie
WebUI.click(findTestObject('Object Repository/Transfer/btn_login'))

//Opóźnienei 2 sekundowe
WebUI.delay(2)

//Zatwierdzenie hasła
WebUI.click(findTestObject('Object Repository/Transfer/btn_password'))

//Kliknij ustawienia
WebUI.click(findTestObject('Object Repository/Change_password/btn_settings'))

//Kliknij hasło i logowanie
WebUI.click(findTestObject('Object Repository/Change_password/btn_settings_pass'))

//Wpisz obecne hasło
WebUI.setText(findTestObject('Object Repository/Change_password/inp_pass'),Haslo)

//Wpisz nowe hasło
WebUI.setText(findTestObject('Object Repository/Change_password/inp_pass_new'),HasloNowe)

//Wpisz potwierdzenie nowego hasła
WebUI.setText(findTestObject('Object Repository/Change_password/inp_pass_confirm'),HasloNowe)

//Wcisnij przycisk zapisz
WebUI.click(findTestObject('Object Repository/Change_password/btn_save'))

//Wpisz kod SMS
WebUI.setText(findTestObject('Object Repository/Change_password/inp_sms'),Sms)

//Wcisnij przycisk zatwierdź
WebUI.click(findTestObject('Object Repository/Change_password/btn_sms_confirm'))

WebUI.delay(2)

Msg = WebUI.getText(findTestObject('Object Repository/Change_password/msg'))
Wiadomosc == Msg

//zamknięcie przeglądarki
WebUI.closeBrowser()
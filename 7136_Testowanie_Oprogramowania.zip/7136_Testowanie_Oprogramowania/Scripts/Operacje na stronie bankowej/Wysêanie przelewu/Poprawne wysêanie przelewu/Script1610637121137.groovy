import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable

//Włączenie przeglądaki
WebUI.openBrowser(rawUrl=GlobalVariable.url)
WebUI.maximizeWindow()

//Zalogowanie
WebUI.click(findTestObject('Object Repository/Transfer/btn_login'))

//Opóźnienei 2 sekundowe
WebUI.delay(2)

//Zatwierdzenie hasła
WebUI.click(findTestObject('Object Repository/Transfer/btn_password'))

//Kliknij przelewy
WebUI.click(findTestObject('Object Repository/Transfer/btn_wiretransfers'))

//Kliknij przelew
WebUI.click(findTestObject('Object Repository/Transfer/btn_wiretransfer'))

//Wpisz Imie i nazwisko
WebUI.setText(findTestObject('Object Repository/Transfer/inp_name'),Nazwa)

//Wpisz nr Konta
WebUI.setText(findTestObject('Object Repository/Transfer/inp_account_nr'),Rachunek)

//Rozwin adres
WebUI.click(findTestObject('Object Repository/Transfer/btn_arrow'))

//Wpisz Adres 1
WebUI.setText(findTestObject('Object Repository/Transfer/inp_address'),Adres1)

//Wpisz Adres 2
WebUI.setText(findTestObject('Object Repository/Transfer/inp_city'),Adres2)

//Wpisz tytuł przelewu
WebUI.setText(findTestObject('Object Repository/Transfer/inp_title'),Tytul)

//Wpisz kwotę przelewu
WebUI.setText(findTestObject('Object Repository/Transfer/inp_amount'),Kwota)

//Wcisnij przycisk dalej
WebUI.click(findTestObject('Object Repository/Transfer/btn_next'))

//Wcisnij przycisk zatwierdź
WebUI.click(findTestObject('Object Repository/Transfer/btn_accept'))

//zamknięcie przeglądarki
WebUI.closeBrowser()
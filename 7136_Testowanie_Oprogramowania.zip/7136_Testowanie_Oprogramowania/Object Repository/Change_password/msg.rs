<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>wiadomosc</description>
   <name>msg</name>
   <tag></tag>
   <elementGuidId>60cbb2b4-f702-487f-89a0-b1305b71bfd8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>app-settings-login-password-step3 span</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[.='Hasło zostało zmienione.']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

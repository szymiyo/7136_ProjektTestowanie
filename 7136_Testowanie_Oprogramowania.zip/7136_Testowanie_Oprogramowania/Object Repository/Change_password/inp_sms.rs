<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Input &quot;Kod SMS&quot;</description>
   <name>inp_sms</name>
   <tag></tag>
   <elementGuidId>e3cd2fc7-a91d-4f3a-8e60-626390c35514</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>[name='password']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

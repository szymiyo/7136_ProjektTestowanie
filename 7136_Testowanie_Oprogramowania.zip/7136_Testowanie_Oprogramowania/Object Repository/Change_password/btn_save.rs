<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Przycisk &quot;Zapisz&quot;</description>
   <name>btn_save</name>
   <tag></tag>
   <elementGuidId>fb703126-f085-4b3c-8c22-5802e19ff601</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.buttons-forward > .btn-primary</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

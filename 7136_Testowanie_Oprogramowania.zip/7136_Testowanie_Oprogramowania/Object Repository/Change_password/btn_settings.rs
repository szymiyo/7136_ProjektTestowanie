<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Przycisk &quot;ustawienia&quot;</description>
   <name>btn_settings</name>
   <tag></tag>
   <elementGuidId>f83f49b8-ea07-4b1d-b9c2-006a28a4862b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span#userbarSettings .userbar-icon-label</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

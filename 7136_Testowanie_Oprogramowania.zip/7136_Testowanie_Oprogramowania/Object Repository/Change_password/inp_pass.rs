<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>input &quot;Obecne hasło&quot;</description>
   <name>inp_pass</name>
   <tag></tag>
   <elementGuidId>89bfb2db-08be-4857-94ab-9f5844816d46</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>[formcontrolname='currentPassword']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>input &quot;tytuł&quot;</description>
   <name>inp_title</name>
   <tag></tag>
   <elementGuidId>61bff724-f14a-4d52-8e27-ec1dd2330771</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#title</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

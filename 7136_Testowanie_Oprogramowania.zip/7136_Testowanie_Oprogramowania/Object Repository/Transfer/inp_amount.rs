<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>input &quot;kwota&quot;</description>
   <name>inp_amount</name>
   <tag></tag>
   <elementGuidId>baf921ec-543a-44c6-8540-c1be86585666</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#amount</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

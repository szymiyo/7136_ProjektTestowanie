<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>przycisk rozwijany &quot;adres odbiorcy&quot;</description>
   <name>btn_arrow</name>
   <tag></tag>
   <elementGuidId>0d662b3e-63b7-425d-8b04-8a3270caf5d2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>[data-target='#recipient-address-group']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>przycisk &quot;dalej&quot;</description>
   <name>btn_next</name>
   <tag></tag>
   <elementGuidId>6b9f176c-c842-48b8-9758-eb258853c52f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>[type='submit']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

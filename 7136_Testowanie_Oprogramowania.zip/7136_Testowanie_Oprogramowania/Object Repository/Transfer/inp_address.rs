<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>input &quot;ulica&quot;</description>
   <name>inp_address</name>
   <tag></tag>
   <elementGuidId>c1b74188-33e7-447e-a24f-d420b4b27e59</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#beneficiaryStreet</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

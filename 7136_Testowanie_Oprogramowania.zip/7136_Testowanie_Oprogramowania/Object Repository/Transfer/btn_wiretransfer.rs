<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>przycisk &quot;przelew&quot;</description>
   <name>btn_wiretransfer</name>
   <tag></tag>
   <elementGuidId>0d967662-8510-4801-b8a7-ed4a539a6201</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>ul[aria-labelledby='menu.transfers'] > li:nth-of-type(1) span</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

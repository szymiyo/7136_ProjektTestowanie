<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>przycisk &quot;przelewy&quot;</description>
   <name>btn_wiretransfers</name>
   <tag></tag>
   <elementGuidId>b8ebfb71-4769-4ce4-8c6e-e62dd485f907</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#menu\.transfers</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

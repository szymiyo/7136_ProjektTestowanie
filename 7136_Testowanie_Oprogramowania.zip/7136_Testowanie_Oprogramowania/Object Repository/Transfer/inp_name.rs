<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>input &quot;nazwa odbiorcy&quot;</description>
   <name>inp_name</name>
   <tag></tag>
   <elementGuidId>55dda557-d1e9-46e7-9b36-e08c8833bf65</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//input[@id='recipient']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
